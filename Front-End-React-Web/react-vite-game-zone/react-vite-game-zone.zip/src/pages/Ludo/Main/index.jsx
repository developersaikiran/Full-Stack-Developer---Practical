import { Col, Row } from "antd";
import { svgIcons } from "@config/svgIcons";
import { HappyCasualMan } from "@config/imageData";
import { Clsx } from "@utils";
// import styles from "./../../../pages/Authentication/Authentication.module.css";
// import AKInput from "@components/AKForms/AKFormControls/AKInputControls/AKInput";

const LudoMainPage = () => {
    return (
        <>
            <div
                className={
                    Clsx("d-flex h-m-inherit",
                        // styles.authenticationWrapper
                    )}
            >
                <Row className="h-full h-m-inherit my-auto mx-0">
                    <Col
                        xs={24}
                        lg={24}
                        xl={12}
                        className={Clsx(
                            "flex items-center justify-center",
                            // styles.authContentCol
                        )}
                        style={{backgroundColor: 'red'}}
                    >
                        <div
                        // className={Clsx(styles.authContent)}
                        >
                            <Row gutter={[20, 20]}>
                                <Col xs={24} className="">
                                    <h2 className="h1 mb-1 title-color fw-700 text-center">
                                        Coming Soon
                                    </h2>
                                    <h3 className="mb-0 small text-color fw-400 text-center">
                                        Our website is currently under construction, enter your
                                        email id to get latest updates and notifications about the
                                        website.
                                    </h3>
                                </Col>
                                <Col xs={24} className="">
                                    {/* <Input type={"text"} placeholder={"@xyz"} /> */}
                                </Col>
                                <Col xs={24} className="">
                                    {/* <Button
                                        customClass=""
                                        type="fill"
                                        handleClick={() => console.log("handleClick")}
                                        size="medium"
                                        block
                                    >
                                        subscribe
                                    </Button> */}
                                </Col>
                                <Col xs={24} className="">
                                    <div className="flex items-center justify-center gap-8">
                                        <a
                                            href="https://www.facebook.com"
                                            target="_blank"
                                            className="social-icons blue"
                                        >
                                            {svgIcons.facebook}
                                        </a>
                                        <a
                                            href="https://google.com"
                                            target="_blank"
                                            className="social-icons red"
                                        >
                                            {svgIcons.google}
                                        </a>
                                        <a
                                            href="https://twitter.com"
                                            target="_blank"
                                            className="social-icons white"
                                        >
                                            {svgIcons.twitter}
                                        </a>
                                    </div>
                                </Col>
                            </Row>
                        </div>
                    </Col>
                    <Col xs={12}
                        // className={styles.authImageCol}
                    >
                        <div className="pa-5 p-0 h-full">
                            <div className={
                                Clsx("bg-owl h-m-inherit",
                                    // styles.authCover
                                )}>
                                <div
                                    // className={styles.authImageContainer}
                                >
                                    <img src={HappyCasualMan} alt="annakoot image"
                                        // className={styles.authImage}
                                    />
                                </div>
                            </div>
                        </div>
                    </Col>
                </Row>
            </div>
        </>
    );
};

export default LudoMainPage;
