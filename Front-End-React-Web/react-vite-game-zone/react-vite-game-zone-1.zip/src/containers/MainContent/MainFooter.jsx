import React from 'react'

export default function MainFooter() {
  return (
    <div>MainFooter</div>
  )
}
