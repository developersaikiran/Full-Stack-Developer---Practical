import React from 'react'

export default function MainSideBar() {
  return (
    <div>MainSideBar</div>
  )
}
