import React from 'react'

export default function MainHeader() {
  return (
    <div>MainHeader</div>
  )
}
