import { turningSpots, victoryStart } from "../../pages/Ludo/Constants/PlotData";
import { playSound } from "../../pages/Ludo/Constants/SoundUtility";
import { selectCurrentPositions, selectDiceNo } from "./gameSelectors";
import { disableTouch, updatePlayerPieceValue } from "./gameSlice";

const delay = (ms) => new Promise(resolve => setTimeout(resolve, ms))

export const handleForwardThunk = (playerNo, id, pos) => async (dispatch, getState) => {

    const state = getState();
    const plottedPieces = selectCurrentPositions(state);
    const diceNo = selectDiceNo(state);

    let alpha = playerNo == 1 ? 'A' : playerNo == 2 ? 'B' : playerNo == 3 ? 'C' : 'D';
    const pieceAtPosition = plottedPieces?.filter(item => item.pos == pos);
    const piece = pieceAtPosition[pieceAtPosition?.findIndex(item => item.id[0] == alpha)];

    dispatch(disableTouch());

    let finalPath = piece.pos;
    const beforePlayerPiece = state.ludoGame[`player${playerNo}`].find(
        item => item.id == id
    );
    let travelCount = beforePlayerPiece.travelCount;

    for(let i=0; i< diceNo; i++){
        const updatePosition = getState();
        const playerPiece = updatePosition?.ludoGame[`player${playerNo}`].find(
            item => item.id == id
        )
        path = playerPiece.pos + 1;
        if(turningSpots.includes(path) && turningSpots[playerNo - 1]){
            path = victoryStart[playerNo - 1];
        }
        if(path == 53){
            path = 1
        }
        finalPath = path;
        travelCount += 1;
        dispatch(updatePlayerPieceValue({
            playerNo: `player${playerNo}`,
            pieceId: playerPiece.id,
            pos: path,
            travelCount: travelCount,
        }));
        playSound('pile_move');
        await delay(200);
    }

    const updatedState = getState()
    const updatedPlottedPieces = selectCurrentPositions(updatedState)
    


}