export const Colors = {
    green: '#00a049',
    red: '#d5151d',
    yellow: '#ffde17',
    blue: '#28aeff',
    borderColor: '#4f6eB2',
}