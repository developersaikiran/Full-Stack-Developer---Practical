import HappyCasualMan from '@images/covers/happy-casual-man.png';

export {
    HappyCasualMan
}